<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="7" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="46" height="62"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="15" y1="63" x2="15" y2="2"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="20" y1="15" x2="48" y2="15"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="20" y1="21" x2="48" y2="21"/>
</svg>
