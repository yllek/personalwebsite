<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<rect x="16" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="32" height="62"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="28" y1="5" x2="36" y2="5"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="16" y1="51" x2="48" y2="51"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="16" y1="9" x2="48" y2="9"/>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" cx="32" cy="57" r="2"/>
</g>
<g>
	<rect x="22" y="23" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="20" height="14"/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="22,35 29,28 33,33 35,31 41,36 	"/>
</g>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="39" cy="26" r="3"/>
</svg>
